<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $sql = "INSERT INTO foods (name, description, price) VALUES ('$name', '$description', '$price')";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil ditambahkan";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Makanan</title>
</head>
<body>
    <h1>Tambah Makanan</h1>
    <form method="post" action="create.php">
        <p>Nama: <input type="text" name="name"></p>
        <p>Deskripsi: <input type="text" name="description"></p>
        <p>Harga: <input type="text" name="price"></p>
        <p><input type="submit" value="Simpan"></p>
    </form>
    <a href="index.php">Kembali</a>
</body>
</html>