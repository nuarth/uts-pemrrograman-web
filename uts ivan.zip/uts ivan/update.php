<?php
include 'config.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $sql = "UPDATE foods SET name='$name', description='$description', price='$price' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil diperbarui";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    header('Location: index.php');
    exit();
}

$sql = "SELECT * FROM foods WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Data tidak ditemukan.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Makanan</title>
</head>
<body>
    <h1>Edit Makanan</h1>
    <form method="post" action="update.php?id=<?php echo $id; ?>">
        <p>Nama: <input type="text" name="name" value="<?php echo $row['name']; ?>"></p>
        <p>Deskripsi: <input type="text" name="description" value="<?php echo $row['description']; ?>"></p>
        <p>Harga: <input type="text" name="price" value="<?php echo $row['price']; ?>"></p>
        <p><input type="submit" value="Simpan"></p>
    </form>
    <a href="index.php">Kembali</a>
</body>
</html>