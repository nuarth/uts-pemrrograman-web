<?php
include 'config.php';

$id = $_GET['id'];

$sql = "SELECT * FROM foods WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Data tidak ditemukan.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Makanan</title>
</head>
<body>
    <h1>Detail Makanan</h1>
    <p>Nama: <?php echo $row['name']; ?></p>
    <p>Deskripsi: <?php echo $row['description']; ?></p>
    <p>Harga: <?php echo $row['price']; ?></p>
    <a href="index.php">Kembali</a>
</body>
</html>